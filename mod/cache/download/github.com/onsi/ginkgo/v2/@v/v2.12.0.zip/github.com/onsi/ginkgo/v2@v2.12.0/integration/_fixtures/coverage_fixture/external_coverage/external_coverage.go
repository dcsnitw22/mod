package external_coverage

func Tested() string {
	return "tested"
}

func TestedByAdditional() string {
	return "tested by additional"
}
