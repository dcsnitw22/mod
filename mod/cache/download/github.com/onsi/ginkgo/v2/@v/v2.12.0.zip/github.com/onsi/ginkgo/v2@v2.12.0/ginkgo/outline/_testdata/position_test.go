package example_test

import (
	. "github.com/onsi/ginkgo/v2"
)

// Describe start=104, end=240
var _ = Describe("104,240", func() {

	/*
	* block comment
	*
	 */

	// line comment

	// It start=209, end=236
	It("209,236", func() {

	})

})
