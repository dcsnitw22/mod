package types

const VERSION = "2.12.0"
