package protobuf

//go:generate protoc --go_out=. simple_message.proto
