**This directory has the implementation of the S2Av2's gRPC-Go client libraries**
